//
//  ViewController.h
//  test
//
//  Created by god on 15/4/29.
//  Copyright (c) 2015年 Geek-Zoo Studio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Samurai.h"

@interface TestCaseViewController : SamuraiActivity

@property (nonatomic, strong) NSString * testCase;

@end

