//
//  NSObject+AutoRuntime.h
//  AutoCoding
//
//  Created by QFish on 1/12/15.
//  Copyright (c) 2015 QFish. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (AutoRuntime)

+ (NSArray *)conformedProtocols;

@end
