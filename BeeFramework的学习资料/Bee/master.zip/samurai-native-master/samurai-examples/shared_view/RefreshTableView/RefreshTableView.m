//
//  AppDelegate.m
//  honey
//
//  Created by god on 14-4-8.
//  Copyright (c) 2014年 geek-zoo studio. All rights reserved.
//

#import "RefreshTableView.h"

#pragma mark -

@implementation RefreshTableView

- (id)initWithFrame:(CGRect)frame style:(UITableViewStyle)style
{
	self = [super initWithFrame:frame style:style];
	if ( self )
	{
		
	}
	return self;
}

- (void)dealloc
{
	
}

@end
